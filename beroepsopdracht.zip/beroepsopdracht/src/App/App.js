import Header from "../Components/Header/Header";
import './App.css';

function App() {
  return (
    <>
    <Header/>
    </>
  );
}

export default App;
